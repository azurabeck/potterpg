import AttributesTab from "../Tabs/Attributes";
import SpellsTab from "../Tabs/Spells";
import PotionsTab from "../Tabs/Potions";
import MysteriesTab from "../Tabs/Mysteries";
import InventoryTab from "../Tabs/Inventory";
import SessionsTab from "../Tabs/Sessions";
import RelationsTab from "../Tabs/Relations";
import GoalsTab from "../Tabs/Goals";
import EnemiesTab from "../Tabs/Enemies";
import LocationsTab from "../Tabs/Locations";
import MagicObjectsTab from "../Tabs/MagicObjects";

export const tabs = [
   { key: "attributes", label: "Atributos", component: AttributesTab, hideRules: true  },
   { key: "spells", label: "Feitiços", component: SpellsTab, hideRules: true },
   { key: "potions", label: "Poções", component: PotionsTab, hideRules: true  },
   { key: "mysteries", label: "Mistérios", component: MysteriesTab, hideRules: true  },
   { key: "inventory", label: "Inventário", component: InventoryTab, hideRules: true },
   { key: "sessions", label: "Sessões", component: SessionsTab, hideRules: true },
   { key: "relations", label: "Relações", component: RelationsTab, hideRules: true },
   { key: "enemies", label: "Adversários", component: EnemiesTab, hideRules: true },
   { key: "magic-objects", label: "Objetos Mágicos", component: MagicObjectsTab, hideRules: true },
   { key: "locations", label: "Locais", component: LocationsTab, hideRules: true },
   { key: "goals", label: "Meta atual", component: GoalsTab, hideRules: true },
];

export const regrasPorAba = {
   attributes: {
      title: "REGRAS DE ATRIBUTOS.",
      text: [
         "Atributos representam as bases do personagem e podem evoluir conforme treino, escolhas e acontecimentos da campanha.",
      ],
      subtitle: "FICHA",
      highlight: "Atributos",
      description:
         "Use esta aba para ajustar valores centrais como coragem, inteligência, magia, proteção e outros atributos globais.",
   },
   spells: {
      title: "REGRAS DE FEITIÇOS.",
      text: [
         "O XP de feitiço pode considerar dado, maestria e dificuldade da magia utilizada.",
         "Feitiços acima do ano do personagem devem receber penalidade ou limitação narrativa.",
      ],
      subtitle: "PROGRESSO",
      highlight: "Maestria",
      description:
         "A maestria representa o quanto o personagem domina o feitiço durante a campanha.",
   },
   potions: {
      title: "REGRAS DE POÇÕES.",
      text: [
         "Poções seguem regra própria de aprendizado e podem exigir ingredientes, aula ou prática guiada.",
      ],
      subtitle: "PROGRESSO",
      highlight: "Preparo",
      description:
         "O avanço depende da execução correta da receita, atenção aos detalhes e resultado final.",
   },
   mysteries: {
      title: "REGRAS DE MISTÉRIOS.",
      text: [
         "Mistérios guardam pistas ativas, suspeitas, locais importantes e descobertas da campanha.",
      ],
      subtitle: "CONTINUIDADE",
      highlight: "Pistas",
      description:
         "Cada sessão pode adicionar, resolver ou alterar um mistério da campanha.",
   },
   inventory: {
      title: "REGRAS DE INVENTÁRIO.",
      text: [
         "Itens carregados pelo personagem podem afetar testes, cenas e opções narrativas.",
      ],
      subtitle: "USO DE ITEM",
      highlight: "Equipamento",
      description:
         "Objetos importantes devem ser registrados para manter continuidade entre sessões.",
   },
   sessions: {
      title: "REGRAS DE SESSÕES.",
      text: ["Cada sessão representa um episódio da campanha do personagem."],
      subtitle: "REGISTRO",
      highlight: "Resumo",
      description:
         "Aqui entrarão os resumos, NPCs, XP ganho, pistas e mudanças de ficha.",
   },
   goals: {
      title: "REGRAS DE META ATUAL.",
      text: [
         "Metas registram objetivos obrigatórios do ano letivo e podem ser conferidas automaticamente pela ficha.",
      ],
      subtitle: "ANO LETIVO",
      highlight: "Progresso",
      description:
         "Use esta aba para acompanhar o que falta concluir e cadastrar novas metas separadas do personagem.",
   },
   relations: {
      title: "REGRAS DE RELAÇÕES.",
      text: [
         "Relações registram vínculos, amizade, rivalidade, confiança e impressões entre personagens.",
      ],
      subtitle: "VÍNCULO",
      highlight: "Relação",
      description:
         "A relação muda conforme as escolhas, diálogos e acontecimentos da campanha.",
   },
   enemies: {
      title: "REGRAS DE ADVERSÁRIOS.",
      text: [
         "Adversários são globais e ficam salvos na coleção enemies do Firestore.",
         "Cada adversário possui HP, ataque principal, ataque secundário e defesa.",
      ],
      subtitle: "COMBATE",
      highlight: "Inimigos",
      description:
         "Use esta aba para registrar criaturas, construtos, bruxos inimigos e obstáculos perigosos.",
   },
   "magic-objects": {
      title: "REGRAS DE OBJETOS MÁGICOS.",
      text: [
         "Objetos mágicos são globais e ficam salvos na coleção objects do Firestore.",
         "Eles podem ser obtidos em missões, comprados em lojas ou criados durante a campanha.",
      ],
      subtitle: "ITENS MÁGICOS",
      highlight: "Objetos",
      description:
         "Use esta aba para cadastrar efeitos, dados, duração, preço e demais detalhes dos objetos mágicos.",
   },
   locations: {
      title: "REGRAS DE LOCAIS.",
      text: [
         "Locais registram lugares importantes da campanha, incluindo acesso, características e importância narrativa.",
         "Cada local fica salvo na coleção locations do Firestore.",
      ],
      subtitle: "CENÁRIO",
      highlight: "Locais",
      description:
         "Use esta aba para registrar casas, salas secretas, florestas, cidades, lojas e outros pontos importantes da campanha.",
   },
};
