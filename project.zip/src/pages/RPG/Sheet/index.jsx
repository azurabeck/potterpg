import { NavLink, Routes, Route } from "react-router-dom";
import { PlusIcon } from "@heroicons/react/24/outline";

import Character from "./Character/index.jsx";
import CreateCharacter from "./CreateCharacter/index.jsx";

const RPGSheet = () => {
   const tabClass = ({ isActive }) =>
      `rounded-xl px-4 py-2 text-sm font-medium transition ${
         isActive
            ? "bg-yellow-400 text-[#2b0038]"
            : "bg-white/10 text-gray-300 hover:bg-white/15 hover:text-yellow-400"
      }`;

   return (
      <main className="min-h-[calc(100vh-65px)] bg-gradient-to-br from-[#2b0038] via-[#3d0052] to-[#09000d] p-6 text-white">
         <section className="mx-auto max-w-7xl">
            <div className="mb-6 flex items-start justify-between">
                <div>
                    <p className="text-sm uppercase tracking-[0.35em] text-yellow-400">
                        Perfil RPG
                    </p>

                    <h1 className="mt-2 text-3xl font-bold">
                        Meus Personagens
                    </h1>

                    <p className="mt-1 text-gray-300">
                        Crie e gerencie suas fichas de campanha.
                    </p>
                </div>

                <NavLink
                    to="/rpg/sheet/create"
                    className="flex h-11 w-11 items-center justify-center rounded-full bg-yellow-400 text-[#2b0038] hover:bg-yellow-300"
                >
                    <PlusIcon className="h-6 w-6" />
                </NavLink>
            </div>

            <nav className="mb-6 flex flex-wrap gap-3">
               <NavLink to="/rpg/sheet" end className={tabClass}>
                  Visão Geral
               </NavLink>

               <NavLink to="/rpg/sheet/attributes" className={tabClass}>
                  Atributos
               </NavLink>

               <NavLink to="/rpg/sheet/spells" className={tabClass}>
                  Feitiços
               </NavLink>

               <NavLink to="/rpg/sheet/potions" className={tabClass}>
                  Poções
               </NavLink>

               <NavLink to="/rpg/sheet/inventory" className={tabClass}>
                  Inventário
               </NavLink>

               <NavLink to="/rpg/sheet/npcs" className={tabClass}>
                  NPCs
               </NavLink>

               <NavLink to="/rpg/sheet/relationships" className={tabClass}>
                  Relações
               </NavLink>

               <NavLink to="/rpg/sheet/mysteries" className={tabClass}>
                  Mistérios
               </NavLink>

               <NavLink to="/rpg/sheet/timeline" className={tabClass}>
                  Linha do Tempo
               </NavLink>
            </nav>

            <section className="rounded-3xl border border-white/10 bg-white/5 p-6 shadow-xl backdrop-blur">
               <Routes>
                  <Route index element={<Character />} />
                  <Route path="attributes" element={<div>Atributos</div>} />
                  <Route path="spells" element={<div>Feitiços aprendidos</div>} />
                  <Route path="potions" element={<div>Poções aprendidas</div>} />
                  <Route path="inventory" element={<div>Inventário</div>} />
                  <Route path="npcs" element={<div>NPCs conhecidos</div>} />
                  <Route path="relationships" element={<div>Relações</div>} />
                  <Route path="mysteries" element={<div>Mistérios</div>} />
                  <Route path="timeline" element={<div>Linha do tempo</div>} />
                  <Route path="create" element={<CreateCharacter />} />
               </Routes>
            </section>
         </section>
      </main>
   );
};

export default RPGSheet;