import masteryRules from "../../../../../assets/json/mastery.json";

export const getMasteryByXp = (nivel, xpAtual = 0) => {
   const regra = masteryRules.maestria.find(
      (item) => item.aprendizado.toLowerCase() === nivel.toLowerCase()
   );

   if (!regra) {
      return {
         maestria: "-",
         dado: "-",
         xp_total: 0,
      };
   }

   let currentMastery = "-";

   Object.entries(regra.xp_maestria).forEach(([maestria, xpNecessario]) => {
      if (Number(xpAtual) >= xpNecessario) {
         currentMastery = maestria;
      }
   });

   return {
      maestria: currentMastery,
      dado: masteryRules.dados_por_maestria[currentMastery] || "-",
      xp_total: regra.xp_total,
   };
};