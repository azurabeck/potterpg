import { useState, useEffect } from "react";
import { auth } from "../../../../services/firebase";
import { getCharactersByUserId } from "../../../../services/rpg/character.service";

const CharacterSheet = () => {
   const [tab, setTab] = useState("summary");
   const [character, setCharacter] = useState(null);
   const [loading, setLoading] = useState(true);

   const loadCharacter = async () => {
      try {
         const user = auth.currentUser;

         if (!user) return;

         const characters = await getCharactersByUserId(user.uid);
            console.log("PERSONAGEM:", characters);

         if (characters.length > 0) {
            setCharacter(characters[0]);
         }
      } catch (error) {
         console.error("Erro ao carregar personagem:", error);
      } finally {
         setLoading(false);
      }
   };

   useEffect(() => {
        const initialize = async () => {
            await loadCharacter();
        };

        initialize();
    }, []);

   if (loading) {
      return (
         <div style={{ padding: "20px" }}>
            <h1>Carregando ficha...</h1>
         </div>
      );
   }

   if (!character) {
      return (
         <div style={{ padding: "20px" }}>
            <h1>Nenhum personagem encontrado</h1>
         </div>
      );
   }

   return (
      <div style={{ padding: "20px" }}>
         <h1>Ficha do Personagem</h1>

         <div
            style={{
               display: "flex",
               gap: "10px",
               marginBottom: "20px",
               flexWrap: "wrap",
            }}
         >
            <button onClick={() => setTab("summary")}>Resumo</button>
            <button onClick={() => setTab("attributes")}>Atributos</button>
            <button onClick={() => setTab("skills")}>Habilidades</button>
            <button onClick={() => setTab("inventory")}>Inventário</button>
            <button onClick={() => setTab("relations")}>Relações</button>
            <button onClick={() => setTab("mysteries")}>Mistérios</button>
         </div>

         {/* RESUMO */}
         {tab === "summary" && (
            <div>
               <h2>Resumo</h2>

               <img
                src={
                    character.image_url ||
                    "https://placehold.co/250x250"
                }
                alt={character.name}
                style={{
                    width: "250px",
                    borderRadius: "12px",
                    marginBottom: "20px",
                }}
                />

               <p>
                <strong>Nome:</strong> {character.name}
                </p>

                <p>
                <strong>Casa:</strong> {character.casa}
                </p>

                <p>
                <strong>Ano:</strong> {character.ano}º Ano
                </p>

                <p>
                <strong>Tipo:</strong> {character.tipo}
                </p>

                <p>
                <strong>Animal:</strong> {character.animal}
                </p>

                <p>
                <strong>Dinheiro:</strong>
                {" "}
                {character.dinheiro?.galeoes ?? 0} Galeões,
                {" "}
                {character.dinheiro?.sicles ?? 0} Sicles,
                {" "}
                {character.dinheiro?.nuques ?? 0} Nuques
                </p>
            </div>
         )}

         {/* ATRIBUTOS */}
         {tab === "attributes" && (
            <div>
               <h2>Atributos</h2>

               {character.atributos ? (
                <ul>
                    {Object.entries(character.atributos).map(
                        ([name, value]) => (
                            <li key={name}>
                            {name}: {value}
                            </li>
                        )
                    )}
                </ul>
                ) : (
                <p>Nenhum atributo cadastrado.</p>
                )}
            </div>
         )}

         {/* HABILIDADES */}
         {tab === "skills" && (
            <div>
               <h2>Habilidades</h2>

               {Object.keys(character.habilidades || {}).length > 0 ? (
                  <ul>
                     {character.habilidades.map((skill, index) => (
                        <li key={index}>
                           {typeof skill === "string"
                              ? skill
                              : `${skill.name} - XP ${skill.xp ?? 0}`}
                        </li>
                     ))}
                  </ul>
               ) : (
                  <p>Nenhuma habilidade cadastrada.</p>
               )}
            </div>
         )}

         {/* INVENTÁRIO */}
         {tab === "inventory" && (
            <div>
               <h2>Inventário</h2>

               {Object.keys(character.pocoes || {}).length > 0 ? (
                  <ul>
                     {character.pocoes.map((item, index) => (
                        <li key={index}>
                           {typeof item === "string"
                              ? item
                              : item.name}
                        </li>
                     ))}
                  </ul>
               ) : (
                  <p>Inventário vazio.</p>
               )}
            </div>
         )}

         {/* RELAÇÕES */}
         {tab === "relations" && (
            <div>
               <h2>Relações</h2>

               {character.relations?.length ? (
                  <ul>
                     {character.relations.map(
                        (relation, index) => (
                           <li key={index}>
                              {relation.name} -{" "}
                              {relation.relationship}
                           </li>
                        )
                     )}
                  </ul>
               ) : (
                  <p>Nenhuma relação cadastrada.</p>
               )}
            </div>
         )}

         {/* MISTÉRIOS */}
         {tab === "mysteries" && (
            <div>
               <h2>Mistérios</h2>

               {character.mysteries?.length ? (
                  <ul>
                     {character.mysteries.map(
                        (mystery, index) => (
                           <li key={index}>
                              {typeof mystery === "string"
                                 ? mystery
                                 : mystery.title}
                           </li>
                        )
                     )}
                  </ul>
               ) : (
                  <p>Nenhum mistério registrado.</p>
               )}
            </div>
         )}
      </div>
   );
}

export default CharacterSheet