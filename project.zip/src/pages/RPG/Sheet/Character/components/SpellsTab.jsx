import { useMemo, useState } from "react";
import { doc, serverTimestamp, updateDoc } from "firebase/firestore";
import { CheckIcon, InformationCircleIcon } from "@heroicons/react/24/outline";
import spellsJson from "../../../../../assets/json/spells_rpg.json";
import { db } from "../../../../../services/firebase";
import { getMasteryByXp } from "../helpers/mastery.helper";

const getSpellsList = () => {
   if (Array.isArray(spellsJson)) return spellsJson;
   if (Array.isArray(spellsJson.data)) return spellsJson.data;
   if (Array.isArray(spellsJson.spells)) return spellsJson.spells;

   return [];
};

const SpellsTab = ({ selectedCharacter, setCharacters }) => {
   const [selectedSpellId, setSelectedSpellId] = useState("");
   const [xpDrafts, setXpDrafts] = useState({});
   const [savingSpellId, setSavingSpellId] = useState("");

   const spells = useMemo(() => getSpellsList(), []);

   const savedSpells = selectedCharacter?.habilidades || {};

   const knownSpellIds = Object.keys(savedSpells);

   const availableSpells = spells.filter(
      (spell) => !knownSpellIds.includes(spell.id)
   );

   const characterSpells = knownSpellIds
      .map((spellId) => {
         const spell = spells.find((item) => item.id === spellId);

         if (!spell) return null;

         return {
            spell,
            savedData: savedSpells[spellId],
         };
      })
      .filter(Boolean);

   const updateCharacterState = (spellId, spellData) => {
      setCharacters((currentCharacters) =>
         currentCharacters.map((character) => {
            if (character.id !== selectedCharacter.id) return character;

            return {
               ...character,
               habilidades: {
                  ...(character.habilidades || {}),
                  [spellId]: spellData,
               },
            };
         })
      );
   };

   const handleAddSpell = async () => {
      if (!selectedSpellId || !selectedCharacter?.id) return;

      const spellData = {
         xp: 0,
      };

      try {
         setSavingSpellId(selectedSpellId);

         const characterRef = doc(db, "characters", selectedCharacter.id);

         await updateDoc(characterRef, {
            [`habilidades.${selectedSpellId}`]: spellData,
            updated_at: serverTimestamp(),
         });

         updateCharacterState(selectedSpellId, spellData);

         setXpDrafts((currentDrafts) => ({
            ...currentDrafts,
            [selectedSpellId]: "0",
         }));

         setSelectedSpellId("");
      } catch (error) {
         console.error("Erro ao adicionar feitiço:", error);
      } finally {
         setSavingSpellId("");
      }
   };

   const handleXpChange = (spellId, value) => {
      if (/^\d*$/.test(value)) {
         setXpDrafts((currentDrafts) => ({
            ...currentDrafts,
            [spellId]: value,
         }));
      }
   };

   const handleSaveXp = async (spellId, currentXp) => {
      const draftValue = xpDrafts[spellId];

      if (draftValue === undefined || draftValue === "" || Number(draftValue) === Number(currentXp)) {
         return;
      }

      const normalizedXp = Number(draftValue);

      try {
         setSavingSpellId(spellId);

         const characterRef = doc(db, "characters", selectedCharacter.id);

         await updateDoc(characterRef, {
            [`habilidades.${spellId}.xp`]: normalizedXp,
            updated_at: serverTimestamp(),
         });

         updateCharacterState(spellId, {
            ...(savedSpells[spellId] || {}),
            xp: normalizedXp,
         });

         setXpDrafts((currentDrafts) => {
            const nextDrafts = { ...currentDrafts };
            delete nextDrafts[spellId];
            return nextDrafts;
         });
      } catch (error) {
         console.error("Erro ao salvar XP do feitiço:", error);
      } finally {
         setSavingSpellId("");
      }
   };

   return (
      <div className="space-y-10">
         <div className="flex gap-2">
            <select
               value={selectedSpellId}
               onChange={(event) => setSelectedSpellId(event.target.value)}
               className="h-10 flex-1 bg-white/20 px-4 text-xs text-white outline-none"
            >
               <option value="">Adicionar Feitiço</option>

               {availableSpells.map((spell) => (
                  <option key={spell.id} value={spell.id}>
                     {spell.attributes?.name}
                  </option>
               ))}
            </select>

            <button
               type="button"
               disabled={!selectedSpellId || savingSpellId === selectedSpellId}
               onClick={handleAddSpell}
               className="h-10 w-24 bg-white/20 text-xs uppercase text-white/70 transition hover:bg-white/30 disabled:cursor-not-allowed disabled:opacity-40"
            >
               Add
            </button>
         </div>

         <div className="grid grid-cols-[48px_1.4fr_90px_130px_1fr_40px] gap-5 text-xs text-purple-100/90">
            <span>Ano</span>
            <span>Nome</span>
            <span>XP Atual</span>
            <span>Maestria → Dado</span>
            <span>Atributo</span>
            <span />
         </div>

         <div className="space-y-4">
            {characterSpells.length ? (
               characterSpells.map(({ spell, savedData }) => {
                  const xpAtual = savedData?.xp ?? 0;
                  const draftXp = xpDrafts[spell.id] ?? String(xpAtual);
                  const hasChanged = Number(draftXp) !== Number(xpAtual);
                  const mastery = getMasteryByXp(
                     spell.attributes?.nivel,
                     xpAtual
                  );

                  return (
                     <div
                        key={spell.id}
                        className="grid grid-cols-[48px_1.4fr_90px_130px_1fr_40px] items-center gap-5 text-xs text-[#736868]"
                     >
                        <span>
                           {spell.attributes?.ano_letivo || "-"}{" "}
                           {spell.attributes?.required ? (
                              <span className="text-yellow-400">★</span>
                           ) : null}
                        </span>

                        <span className="flex items-center gap-2">
                           {spell.attributes?.name}

                           {spell.attributes?.effect ? (
                              <InformationCircleIcon
                                 className="h-4 w-4 text-white"
                                 title={spell.attributes.effect}
                              />
                           ) : null}
                        </span>

                        <input
                           type="text"
                           value={draftXp}
                           onChange={(event) =>
                              handleXpChange(spell.id, event.target.value)
                           }
                           className="w-full bg-[#9d564c] px-3 py-1 text-center text-xs text-white outline-none ring-1 ring-transparent focus:ring-yellow-400"
                        />

                        <span>
                           {mastery.maestria} → {mastery.dado}
                        </span>

                        <span>
                           {spell.attributes?.atributo ||
                              spell.attributes?.attribute ||
                              "-"}
                        </span>

                        <button
                           type="button"
                           disabled={!hasChanged || savingSpellId === spell.id}
                           onClick={() => handleSaveXp(spell.id, xpAtual)}
                           className={`flex h-7 w-7 items-center justify-center rounded transition ${
                              hasChanged && savingSpellId !== spell.id
                                 ? "bg-yellow-400 text-[#2b0038] hover:bg-yellow-300"
                                 : "bg-white/10 text-white/30"
                           }`}
                           title="Salvar XP"
                        >
                           <CheckIcon className="h-4 w-4" />
                        </button>
                     </div>
                  );
               })
            ) : (
               <div className="flex min-h-[220px] items-center justify-center text-center text-sm text-purple-200/70">
                  Nenhum feitiço cadastrado.
               </div>
            )}
         </div>

         <div className="border-t border-white/20 pt-4 text-xs text-[#736868]">
            <span className="text-yellow-400">★</span> Indica que é obrigatório
            aprender o feitiço no ano indicado.
         </div>
      </div>
   );
};

export default SpellsTab;